### Chạy Node bằng roslaunch

rosrun chỉ có thể chạy một lúc một Node từ một package trong khi roslaunch có thể chạy nhiều Node từ nhiều package.

roslaunch tự khởi động roscore (nếu chưa có) còn rosrun thì không.

Một tệp .launch thực chất là một tệp XML nên cách tạo cũng khá dễ dàng. Đầu tiên bạn tạo một folder tên launch rồi tạo một file text đặt tên là my_cam.launch. Nội dung của file này như sau:

<launch>
    <arg name="camera_name" default="/dev/video0"/>
    <node name="my_webcam" pkg="my_cam" type="image_publisher_launch.py" output="screen">
        <param name="camera_name" type="string" value="$(arg camera_name)" />
    </node>
</launch>


Giải thích: Một tệp launch bắt đầu bằng tag <launch> và kết thúc bằng tag </launch>. 

Đầu tiên mình tạo một biến (argument) có tên camera_name và giá trị mặc định của nó là /dev/video0.
Khi muốn dùng biến này trong launch file thì gọi nó bằng $(arg camera_name) như ở dòng thứ 4.

Dòng tiếp theo định nghĩa Node mà mình muốn chạy, trong đó name là tên của Node (tên này sẽ được dùng nếu nó khác với tên bạn đặt trong tệp Python), pkg là tên package (ở đây là my_cam), type là tên file (ở đây là image_publisher_launch.py), output là để chọn cách hiển thị các thông tin (nếu là screen thì thông tin sẽ được print ra màn hình, còn là log thì sẽ được lưu trong một file log). 

Cuối cùng, tạo một tham số (parameter) có tên camera_name với type string và giá trị là giống với biến camera_name bên trên. Bạn có thể sử dụng tham số này trong code và vì thế không cần phải sửa code mỗi khi cần thay đổi một thông tin nào đó. 

Cụ thể, mình đã tạo một file image_publisher_launch.py. File này nội dung gần giống y hệt như image_publisher.py chỉ khác ở chỗ mình cho nó thành một class và khi khởi tạo class thì có dòng:

self.capture = cv2.VideoCapture(rospy.get_param("my_webcam/camera_name"))

Ở đây thay vì cho một giá trị mặc định như trước thì bạn dùng hàm rospy.get_param để lấy tham số từ launch file. Vì thế nếu ví dụ bạn dùng một camera có tên khác, thì bạn chỉ cần thay đổi launch file. Hoặc cách hay hơn là khi chạy roslaunch bạn có thể dùng biến (argument) đã được tạo ở đây <arg name="camera_name" default="/dev/video0"/>

Chạy roslaunch:

roslaunch my_cam my_cam.launch camera_name:="/dev/video0"

Nếu bạn sử dụng giá trị mặc định của các biến bạn chỉ cần chạy roslaunch my_cam my_cam.launch. Nhưng nếu bạn dùng một camera khác hoặc tên của nó không phải là /dev/video0 thì bạn chỉ cần thay đổi tên ở lệnh bên trên

# # Cau lenh chay
roslaunch my_cam my_cam.launch camera_name:="/dev/video4"


# Cach viet 1 file launch 

Co ban se co cac thanh phan sau (neu copy thi xoa het chu thich)

<launch>
    <arg name="camera_name" default="/dev/video4"/>  ## cho phep nguoi dung tryen tham so thong qua terminal ma khong sua file launch vi du nhu: camera_name:="/dev/video4" ##
    <node name="my_cam" pkg="my_cam" type="image_publish_launch.py" output="screen">
        <param name="camera_name" type="string" value="$(arg camera_name)" /> ## muon truyen tham so qua parameter server cua ROS, Khi node cần một tham số cố định hoặc truyền từ file launch, dang dc lay tu arg name ben tren dong 47
    </node>
</launch>

neu bo xung them subcriber thi nhu sau

<launch>
    <arg name="camera_name" default="/dev/video4"/> 
    <node name="my_webcam" pkg="my_cam" type="image_publish_launch.py" output="screen">
        <param name="camera_name" type="string" value="$(arg camera_name)" />
    </node>
    <!-- Node Subscriber -->
    <node name="image_subscriber" pkg="my_cam" type="image_subcribe.py" output="screen" />
</launch>

Cau lenh khi chay co the nhu sau, coi nhu truyen tham so la mac dinh, khong truyen them doi so arg
roslaunch my_cam my_cam.launch 


# hien thi bieu do lien ket topic - node
 1. cai dat thong so de hien thi HZ: 
 rosparam set enable_statistics true
2. chay node sau do
roslaunch my_cam my_cam.launch 
3. hien bieu do
rqt_graph  # thuc hien tat/bat o tich TF
4. Co the do tan so truc tiep len topic 
rostopic hz /image_raw # vi du do la topic /image_raw

