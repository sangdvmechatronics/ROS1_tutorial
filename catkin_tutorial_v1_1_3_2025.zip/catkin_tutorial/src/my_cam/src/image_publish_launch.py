#!/usr/bin/python3
import rospy
import cv2
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image

class ImagePublisher:
    def __init__(self):
        """Khởi tạo đối tượng với nguồn camera từ tham số ROS"""
        camera_source = rospy.get_param("my_webcam/camera_name", "/dev/video4")  # Lấy từ tham số ROS

        self.image_pub = rospy.Publisher("image_raw", Image, queue_size=10)
        self.bridge = CvBridge()
        self.capture = cv2.VideoCapture(camera_source)

        if not self.capture.isOpened():
            rospy.logerr(f"Không thể mở camera tại {camera_source}")
            raise RuntimeError("Failed to open video capture")

    def publish_image(self):
        """Gửi ảnh từ camera lên topic /image_raw"""
        while not rospy.is_shutdown():
            ret, img = self.capture.read()
            if not ret:
                rospy.logerr("Không thể lấy khung hình!")
                break

            try:
                img_msg = self.bridge.cv2_to_imgmsg(img, "bgr8")
                self.image_pub.publish(img_msg)
                cv2.waitKey(1)
            except CvBridgeError as error:
                rospy.logerr(f"Lỗi CvBridge: {error}")

    def run(self):
        """Bắt đầu tiến trình gửi ảnh"""
        rospy.init_node("my_cam", anonymous=True)
        rospy.loginfo("Đang gửi ảnh lên topic /image_raw ...")
        rate = rospy.Rate(15)  # 20 Hz (cứ mỗi 1/20 giây sẽ lặp lại 1 lần)

        try:
            while not rospy.is_shutdown():

                self.publish_image()
                rate.sleep()  # Chờ để đảm bảo tần số là 20 Hz
        except rospy.ROSInterruptException:
            rospy.loginfo("Node dừng lại.")
        finally:
            self.capture.release()  # Giải phóng camera
            cv2.destroyAllWindows()

if __name__ == "__main__":
    cam_publisher = ImagePublisher()
    cam_publisher.run()
